# pycram 0.0.1
A pure python implementation of the Shamir Secret Sharing scheme for use with BIP-39 mnemonic codes. Split a 24-word mnemonic phrase into several shares, and set a minimum threshold to recover your original phrase.

## Install
Coming soon.

## Quick Start
Currently under construciton.
